-- biscuit_iam.sql
-- SQL installation script for Biscuit IAM
-- PostgreSQL 16+ compatible

-- Create the index access method handler function
CREATE FUNCTION biscuit_handler(internal)
RETURNS index_am_handler
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT;

-- Create the index access method
CREATE ACCESS METHOD biscuit TYPE INDEX HANDLER biscuit_handler;

-- Create operator class for text (default) - this handles text, varchar, and bpchar
CREATE OPERATOR CLASS biscuit_text_ops
DEFAULT FOR TYPE text USING biscuit AS
    OPERATOR 1 ~~ (text, text),
    FUNCTION 1 hashtext(text);

-- Note: varchar and bpchar will automatically use text operators since they're text-like types
-- If you need explicit support for other types, create separate operator families

COMMENT ON ACCESS METHOD biscuit IS 'Biscuit index access method for efficient pattern matching on text columns';
COMMENT ON FUNCTION biscuit_handler(internal) IS 'Index access method handler for Biscuit indexes';
COMMENT ON OPERATOR CLASS biscuit_text_ops USING biscuit IS 'Operator class for text pattern matching with Biscuit indexes';

-- Usage examples:
/*

-- Drop old extension if exists
DROP EXTENSION IF EXISTS biscuit_iam CASCADE;
CREATE EXTENSION biscuit_iam;

-- Basic table setup
CREATE TABLE test_table (
    id serial PRIMARY KEY, 
    seq text NOT NULL
);

-- Insert test data
INSERT INTO test_table (seq) VALUES 
    ('ACGTACGT'), 
    ('TGCATGCA'), 
    ('AAAA'), 
    ('CCCCGGGG'),
    ('ATCGATCG'),
    ('GCTAGCTA');

-- Create Biscuit index
CREATE INDEX idx_seq ON test_table USING biscuit(seq);

-- Analyze the table
ANALYZE test_table;

-- Force index usage for testing
SET enable_seqscan = off;
SET enable_bitmapscan = on;

-- Test queries that should use the index:

-- Exact match
EXPLAIN ANALYZE SELECT * FROM test_table WHERE seq LIKE 'AAAA';

-- Prefix match
EXPLAIN ANALYZE SELECT * FROM test_table WHERE seq LIKE 'ACG%';

-- Suffix match
EXPLAIN ANALYZE SELECT * FROM test_table WHERE seq LIKE '%GCTA';

-- Contains pattern
EXPLAIN ANALYZE SELECT * FROM test_table WHERE seq LIKE '%CGT%';

-- Multiple patterns
EXPLAIN ANALYZE SELECT * FROM test_table WHERE seq LIKE '%AT%CG%';

-- Wildcard patterns
EXPLAIN ANALYZE SELECT * FROM test_table WHERE seq LIKE 'A_G_';

-- Check index usage
EXPLAIN (ANALYZE, BUFFERS, VERBOSE) 
SELECT * FROM test_table WHERE seq LIKE '%CGT%';

*/