-- ============================================================================
-- BISCUIT vs PG_TRGM COMPREHENSIVE BENCHMARK
-- Compares pattern matching performance with REAL patterns from data
-- WITH WARM START OPTIMIZATION FOR BISCUIT
-- ============================================================================

-- Enable timing
--\timing on

DO $$ BEGIN RAISE NOTICE '=== BENCHMARK SETUP STARTING ==='; END $$;

-- ============================================================================
-- STEP 1: CREATE TEST TABLE
-- ============================================================================

DO $$ BEGIN RAISE NOTICE 'Step 1: Creating test table with 1M rows...'; END $$;

DROP TABLE IF EXISTS benchmark_data CASCADE;

CREATE TABLE benchmark_data (
    userid VARCHAR(15) PRIMARY KEY,
    name VARCHAR(15) NOT NULL,
    place VARCHAR(15) NOT NULL,
    phone VARCHAR(10) NOT NULL
);

-- ============================================================================
-- STEP 2: POPULATE WITH RANDOM DATA (FIXED)
-- ============================================================================

DO $$ BEGIN RAISE NOTICE 'Step 2: Generating 1,000,000 random records...'; END $$;

INSERT INTO benchmark_data (userid, name, place, phone)
SELECT 
    -- userid: unique, max 15 chars - use row number with limited MD5 prefix
    substr(md5(i::text), 1, 8) || LPAD(i::text, 6, '0'),
    -- name: random alphanumeric 6-15 chars
    substr(md5(random()::text), 1, 6 + (random() * 9)::int),
    -- place: random alphanumeric 6-15 chars
    substr(md5(random()::text), 1, 6 + (random() * 9)::int),
    -- phone: 10-digit number
    lpad(floor(random() * 10000000000)::text, 10, '0')
FROM generate_series(1, 1000000) i;

DO $$ BEGIN RAISE NOTICE 'Data generation complete!'; END $$;

-- ============================================================================
-- STEP 2.5: EXTRACT REAL PATTERNS FROM DATA
-- ============================================================================

DO $$ BEGIN RAISE NOTICE 'Step 2.5: Extracting real patterns from generated data...'; END $$;

DROP TABLE IF EXISTS test_patterns_source;

-- Sample diverse records for pattern extraction
-- Fix: Move random() into subquery to avoid ORDER BY issue with DISTINCT
CREATE TEMP TABLE test_patterns_source AS
SELECT name 
FROM (
    SELECT DISTINCT name, random() as rnd
    FROM benchmark_data
) sub
ORDER BY rnd
LIMIT 100;

DO $$ BEGIN RAISE NOTICE 'Sampled 100 unique names for pattern generation'; END $$;

-- Display sample data
DO $$ BEGIN RAISE NOTICE 'Sample data from table:'; END $$;

SELECT name FROM test_patterns_source LIMIT 10;

-- ============================================================================
-- STEP 3: CREATE RESULTS TABLES
-- ============================================================================

DO $$ BEGIN RAISE NOTICE 'Step 3: Creating results tables...'; END $$;

DROP TABLE IF EXISTS trgm_results CASCADE;
DROP TABLE IF EXISTS biscuit_results CASCADE;
DROP TABLE IF EXISTS index_build_stats CASCADE;

CREATE TABLE trgm_results (
    pattern_id SERIAL PRIMARY KEY,
    pattern_type VARCHAR(50),
    pattern TEXT,
    execution_time_ms NUMERIC(10, 3),
    result_count INTEGER
);

CREATE TABLE biscuit_results (
    pattern_id SERIAL PRIMARY KEY,
    pattern_type VARCHAR(50),
    pattern TEXT,
    execution_time_ms NUMERIC(10, 3),
    result_count INTEGER
);

CREATE TABLE index_build_stats (
    index_type VARCHAR(20) PRIMARY KEY,
    build_time_ms NUMERIC(10, 3),
    index_size_mb NUMERIC(10, 2)
);

-- ============================================================================
-- STEP 4: BUILD PG_TRGM INDEX AND BENCHMARK
-- ============================================================================

DO $$ BEGIN RAISE NOTICE '=== PHASE 1: PG_TRGM INDEX ==='; END $$;

-- Create extension if not exists
CREATE EXTENSION IF NOT EXISTS pg_trgm;

DO $$ 
DECLARE
    start_time TIMESTAMP;
    end_time TIMESTAMP;
    build_time_ms NUMERIC;
BEGIN
    RAISE NOTICE 'Building pg_trgm GIN index on name column...';
    start_time := clock_timestamp();
    
    CREATE INDEX idx_trgm_name ON benchmark_data USING gin (name gin_trgm_ops);
    
    end_time := clock_timestamp();
    build_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
    
    INSERT INTO index_build_stats (index_type, build_time_ms, index_size_mb)
    VALUES ('pg_trgm', build_time_ms, 
            pg_relation_size('idx_trgm_name'::regclass) / 1024.0 / 1024.0);
    
    RAISE NOTICE 'pg_trgm index built in % ms', build_time_ms;
END $$;

-- Run ANALYZE to update statistics
ANALYZE benchmark_data;

DO $$ BEGIN RAISE NOTICE 'Warming up pg_trgm index...'; END $$;

-- WARM-UP: Run sample queries
DO $$
DECLARE
    dummy_count INTEGER;
    sample_name TEXT;
BEGIN
    -- Get a sample name
    SELECT name INTO sample_name FROM benchmark_data LIMIT 1;
    
    -- Run warm-up queries with real patterns
    SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
    WHERE name LIKE substr(sample_name, 1, 2) || '%';
    
    SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
    WHERE name LIKE '%' || substr(sample_name, 3, 2) || '%';
    
    SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
    WHERE name LIKE '%' || substr(sample_name, -2);
    
    RAISE NOTICE 'pg_trgm warm-up complete';
END $$;

-- ============================================================================
-- PG_TRGM PATTERN TESTS WITH REAL PATTERNS
-- ============================================================================

DO $$ BEGIN RAISE NOTICE 'Running pg_trgm pattern queries with REAL patterns...'; END $$;

DO $$
DECLARE
    start_time TIMESTAMP;
    end_time TIMESTAMP;
    exec_time_ms NUMERIC;
    result_cnt INTEGER;
    pattern_type TEXT;
    pattern TEXT;
    sample_name TEXT;
    test_count INTEGER := 0;
    cur CURSOR FOR SELECT name FROM test_patterns_source;
BEGIN
    OPEN cur;
    
    -- For each sampled name, generate multiple pattern types
    FOR i IN 1..15 LOOP
        FETCH cur INTO sample_name;
        EXIT WHEN NOT FOUND;
        
        -- Test 1: Exact match
        pattern_type := 'exact';
        pattern := sample_name;
        start_time := clock_timestamp();
        EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
        INTO result_cnt;
        end_time := clock_timestamp();
        exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
        INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
        VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
        test_count := test_count + 1;
        
        -- Test 2: Prefix (first 2 chars)
        IF length(sample_name) >= 2 THEN
            pattern_type := 'prefix_2char';
            pattern := substr(sample_name, 1, 2) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 3: Prefix (first 3 chars)
        IF length(sample_name) >= 3 THEN
            pattern_type := 'prefix_3char';
            pattern := substr(sample_name, 1, 3) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 4: Suffix (last 2 chars)
        IF length(sample_name) >= 2 THEN
            pattern_type := 'suffix_2char';
            pattern := '%' || substr(sample_name, -2);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 5: Suffix (last 3 chars)
        IF length(sample_name) >= 3 THEN
            pattern_type := 'suffix_3char';
            pattern := '%' || substr(sample_name, -3);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 6: Substring (middle 2 chars)
        IF length(sample_name) >= 4 THEN
            pattern_type := 'substring_2char';
            pattern := '%' || substr(sample_name, 2, 2) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 7: Substring (middle 3 chars)
        IF length(sample_name) >= 5 THEN
            pattern_type := 'substring_3char';
            pattern := '%' || substr(sample_name, 2, 3) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 8: Infix (first 2 + last 2)
        IF length(sample_name) >= 4 THEN
            pattern_type := 'infix';
            pattern := substr(sample_name, 1, 2) || '%' || substr(sample_name, -2);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 9: Underscore only (match exact length)
        pattern_type := 'underscore_only';
        pattern := repeat('_', length(sample_name));
        start_time := clock_timestamp();
        EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
        INTO result_cnt;
        end_time := clock_timestamp();
        exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
        INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
        VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
        test_count := test_count + 1;
        
        -- Test 10: Multi-wildcard (char_%_char)
        IF length(sample_name) >= 4 THEN
            pattern_type := 'multi_wildcard';
            pattern := substr(sample_name, 1, 1) || '_%_' || substr(sample_name, -1);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO trgm_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        IF i % 5 = 0 THEN
            RAISE NOTICE 'Completed pg_trgm pattern generation: % patterns tested', test_count;
        END IF;
    END LOOP;
    
    CLOSE cur;
    RAISE NOTICE 'pg_trgm testing complete! Total patterns tested: %', test_count;
END $$;

-- ============================================================================
-- STEP 5: DROP PG_TRGM, BUILD BISCUIT INDEX (ONCE!)
-- ============================================================================

DO $$ BEGIN RAISE NOTICE '=== PHASE 2: BISCUIT INDEX ==='; END $$;

-- Drop pg_trgm index
DROP INDEX IF EXISTS idx_trgm_name;

DO $$ BEGIN RAISE NOTICE 'Dropped pg_trgm index'; END $$;

-- Check if biscuit extension/index type is available
DO $$
DECLARE
    biscuit_available BOOLEAN;
BEGIN
    -- Check if biscuit access method exists
    SELECT EXISTS(
        SELECT 1 FROM pg_am WHERE amname = 'biscuit'
    ) INTO biscuit_available;
    
    IF NOT biscuit_available THEN
        RAISE EXCEPTION 'Biscuit index access method is not available. Please install the biscuit extension.';
    END IF;
    
    RAISE NOTICE 'Biscuit access method is available';
END $$;

-- Build Biscuit index ONCE
DO $$ 
DECLARE
    start_time TIMESTAMP;
    end_time TIMESTAMP;
    build_time_ms NUMERIC;
BEGIN
    RAISE NOTICE 'Building Biscuit index on name column...';
    start_time := clock_timestamp();
    
    CREATE INDEX idx_biscuit_name ON benchmark_data USING biscuit (name);
    
    end_time := clock_timestamp();
    build_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
    
    INSERT INTO index_build_stats (index_type, build_time_ms, index_size_mb)
    VALUES ('biscuit', build_time_ms, 
            pg_relation_size('idx_biscuit_name'::regclass) / 1024.0 / 1024.0);
    
    RAISE NOTICE 'Biscuit index built in % ms', build_time_ms;
END $$;

-- Run ANALYZE to update statistics
ANALYZE benchmark_data;

-- ============================================================================
-- CRITICAL: WARM START FOR BISCUIT INDEX
-- ============================================================================

DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '*** WARMING UP BISCUIT INDEX (3 rounds) ***'; END $$;

-- WARM-UP ROUNDS
DO $$
DECLARE
    dummy_count INTEGER;
    sample_name TEXT;
    round_num INTEGER;
    start_time TIMESTAMP;
    end_time TIMESTAMP;
BEGIN
    SELECT name INTO sample_name FROM benchmark_data LIMIT 1;
    
    FOR round_num IN 1..3 LOOP
        start_time := clock_timestamp();
        
        SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
        WHERE name LIKE substr(sample_name, 1, 2) || '%';
        
        SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
        WHERE name LIKE '%' || substr(sample_name, 2, 2) || '%';
        
        SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
        WHERE name LIKE '%' || substr(sample_name, -2);
        
        SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
        WHERE name LIKE substr(sample_name, 1, 2) || '%' || substr(sample_name, -2);
        
        SELECT COUNT(*) INTO dummy_count FROM benchmark_data 
        WHERE name LIKE repeat('_', length(sample_name));
        
        end_time := clock_timestamp();
        RAISE NOTICE 'Warm-up Round % complete in % ms', 
            round_num, EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
    END LOOP;
END $$;

DO $$ BEGIN RAISE NOTICE 'Biscuit index is now WARM and ready!'; END $$;
DO $$ BEGIN RAISE NOTICE ''; END $$;

-- ============================================================================
-- BISCUIT PATTERN TESTS (SAME PATTERNS AS PG_TRGM)
-- ============================================================================

DO $$ BEGIN RAISE NOTICE 'Running Biscuit pattern queries (with warm cache)...'; END $$;

DO $$
DECLARE
    start_time TIMESTAMP;
    end_time TIMESTAMP;
    exec_time_ms NUMERIC;
    result_cnt INTEGER;
    pattern_type TEXT;
    pattern TEXT;
    sample_name TEXT;
    test_count INTEGER := 0;
    cur CURSOR FOR SELECT name FROM test_patterns_source;
BEGIN
    OPEN cur;
    
    -- Use SAME patterns as pg_trgm tests
    FOR i IN 1..15 LOOP
        FETCH cur INTO sample_name;
        EXIT WHEN NOT FOUND;
        
        -- Test 1: Exact match
        pattern_type := 'exact';
        pattern := sample_name;
        start_time := clock_timestamp();
        EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
        INTO result_cnt;
        end_time := clock_timestamp();
        exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
        INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
        VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
        test_count := test_count + 1;
        
        -- Test 2: Prefix (first 2 chars)
        IF length(sample_name) >= 2 THEN
            pattern_type := 'prefix_2char';
            pattern := substr(sample_name, 1, 2) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 3: Prefix (first 3 chars)
        IF length(sample_name) >= 3 THEN
            pattern_type := 'prefix_3char';
            pattern := substr(sample_name, 1, 3) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 4: Suffix (last 2 chars)
        IF length(sample_name) >= 2 THEN
            pattern_type := 'suffix_2char';
            pattern := '%' || substr(sample_name, -2);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 5: Suffix (last 3 chars)
        IF length(sample_name) >= 3 THEN
            pattern_type := 'suffix_3char';
            pattern := '%' || substr(sample_name, -3);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 6: Substring (middle 2 chars)
        IF length(sample_name) >= 4 THEN
            pattern_type := 'substring_2char';
            pattern := '%' || substr(sample_name, 2, 2) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 7: Substring (middle 3 chars)
        IF length(sample_name) >= 5 THEN
            pattern_type := 'substring_3char';
            pattern := '%' || substr(sample_name, 2, 3) || '%';
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 8: Infix (first 2 + last 2)
        IF length(sample_name) >= 4 THEN
            pattern_type := 'infix';
            pattern := substr(sample_name, 1, 2) || '%' || substr(sample_name, -2);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        -- Test 9: Underscore only (match exact length)
        pattern_type := 'underscore_only';
        pattern := repeat('_', length(sample_name));
        start_time := clock_timestamp();
        EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
        INTO result_cnt;
        end_time := clock_timestamp();
        exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
        INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
        VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
        test_count := test_count + 1;
        
        -- Test 10: Multi-wildcard (char_%_char)
        IF length(sample_name) >= 4 THEN
            pattern_type := 'multi_wildcard';
            pattern := substr(sample_name, 1, 1) || '_%_' || substr(sample_name, -1);
            start_time := clock_timestamp();
            EXECUTE format('SELECT COUNT(*) FROM benchmark_data WHERE name LIKE %L', pattern)
            INTO result_cnt;
            end_time := clock_timestamp();
            exec_time_ms := EXTRACT(EPOCH FROM (end_time - start_time)) * 1000;
            INSERT INTO biscuit_results (pattern_type, pattern, execution_time_ms, result_count)
            VALUES (pattern_type, pattern, exec_time_ms, result_cnt);
            test_count := test_count + 1;
        END IF;
        
        IF i % 5 = 0 THEN
            RAISE NOTICE 'Completed Biscuit pattern testing: % patterns tested', test_count;
        END IF;
    END LOOP;
    
    CLOSE cur;
    RAISE NOTICE 'Biscuit testing complete! Total patterns tested: %', test_count;
END $$;

-- ============================================================================
-- STEP 6: GENERATE COMPARISON REPORT
-- ============================================================================

DO $$ BEGIN RAISE NOTICE '=== GENERATING COMPARISON REPORT ==='; END $$;

-- Join results and compare
DROP TABLE IF EXISTS performance_comparison;

CREATE TABLE performance_comparison AS
SELECT 
    t.pattern_type,
    t.pattern,
    t.result_count AS trgm_count,
    b.result_count AS biscuit_count,
    t.execution_time_ms AS trgm_time_ms,
    b.execution_time_ms AS biscuit_time_ms,
    ROUND((t.execution_time_ms - b.execution_time_ms) / NULLIF(t.execution_time_ms, 0) * 100, 2) AS speedup_pct,
    ROUND(t.execution_time_ms / NULLIF(b.execution_time_ms, 0), 2) AS speedup_factor,
    CASE 
        WHEN b.execution_time_ms < t.execution_time_ms THEN 'Biscuit Faster'
        WHEN b.execution_time_ms > t.execution_time_ms THEN 'pg_trgm Faster'
        ELSE 'Tie'
    END AS winner
FROM trgm_results t
INNER JOIN biscuit_results b 
    ON t.pattern_type = b.pattern_type 
    AND t.pattern = b.pattern
ORDER BY t.pattern_id;

-- Verify result counts match
DO $$
DECLARE
    mismatch_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO mismatch_count
    FROM performance_comparison
    WHERE trgm_count != biscuit_count;
    
    IF mismatch_count > 0 THEN
        RAISE WARNING 'Found % patterns where result counts do not match between pg_trgm and biscuit!', mismatch_count;
    ELSE
        RAISE NOTICE 'All result counts match between pg_trgm and biscuit - results validated!';
    END IF;
END $$;

-- ============================================================================
-- DISPLAY RESULTS
-- ============================================================================

DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '============================================'; END $$;
DO $$ BEGIN RAISE NOTICE '         BENCHMARK RESULTS SUMMARY'; END $$;
DO $$ BEGIN RAISE NOTICE '         (With Real Patterns & Warm Start)'; END $$;
DO $$ BEGIN RAISE NOTICE '============================================'; END $$;

-- Index build comparison
DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '--- INDEX BUILD STATISTICS ---'; END $$;

SELECT 
    index_type,
    ROUND(build_time_ms, 2) AS build_time_ms,
    ROUND(index_size_mb, 2) AS size_mb
FROM index_build_stats
ORDER BY index_type;

-- Pattern type summary
DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '--- PERFORMANCE BY PATTERN TYPE ---'; END $$;

SELECT 
    pattern_type,
    COUNT(*) AS tests,
    ROUND(AVG(trgm_time_ms), 3) AS avg_trgm_ms,
    ROUND(AVG(biscuit_time_ms), 3) AS avg_biscuit_ms,
    ROUND(AVG(speedup_pct), 2) AS avg_speedup_pct,
    ROUND(AVG(speedup_factor), 2) AS avg_speedup_x,
    SUM(CASE WHEN winner = 'Biscuit Faster' THEN 1 ELSE 0 END) AS biscuit_wins,
    SUM(CASE WHEN winner = 'pg_trgm Faster' THEN 1 ELSE 0 END) AS trgm_wins
FROM performance_comparison
GROUP BY pattern_type
ORDER BY avg_speedup_pct DESC;

-- Overall summary
DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '--- OVERALL SUMMARY ---'; END $$;

SELECT 
    COUNT(*) AS total_tests,
    ROUND(AVG(trgm_time_ms), 3) AS avg_trgm_ms,
    ROUND(AVG(biscuit_time_ms), 3) AS avg_biscuit_ms,
    ROUND(AVG(speedup_pct), 2) AS avg_speedup_pct,
    ROUND(AVG(speedup_factor), 2) AS avg_speedup_x,
    ROUND(SUM(trgm_time_ms), 2) AS total_trgm_ms,
    ROUND(SUM(biscuit_time_ms), 2) AS total_biscuit_ms,
    SUM(CASE WHEN winner = 'Biscuit Faster' THEN 1 ELSE 0 END) AS biscuit_wins,
    SUM(CASE WHEN winner = 'pg_trgm Faster' THEN 1 ELSE 0 END) AS trgm_wins,
    SUM(CASE WHEN winner = 'Tie' THEN 1 ELSE 0 END) AS ties
FROM performance_comparison;

-- Top 10 fastest Biscuit wins
DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '--- TOP 10 BISCUIT PERFORMANCE WINS ---'; END $$;

SELECT 
    pattern_type,
    pattern,
    ROUND(trgm_time_ms, 3) AS trgm_ms,
    ROUND(biscuit_time_ms, 3) AS biscuit_ms,
    ROUND(speedup_pct, 2) AS speedup_pct,
    ROUND(speedup_factor, 2) AS speedup_x
FROM performance_comparison
WHERE winner = 'Biscuit Faster'
ORDER BY speedup_pct DESC
LIMIT 10;

-- Top 10 cases where pg_trgm was faster (if any)
DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '--- TOP 10 PG_TRGM PERFORMANCE WINS (if any) ---'; END $$;

SELECT 
    pattern_type,
    pattern,
    ROUND(trgm_time_ms, 3) AS trgm_ms,
    ROUND(biscuit_time_ms, 3) AS biscuit_ms,
    ROUND(speedup_pct, 2) AS speedup_pct,
    ROUND(speedup_factor, 2) AS speedup_x
FROM performance_comparison
WHERE winner = 'pg_trgm Faster'
ORDER BY speedup_pct ASC
LIMIT 10;

-- Show any result count mismatches
DO $$ 
DECLARE
    mismatch_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO mismatch_count
    FROM performance_comparison
    WHERE trgm_count != biscuit_count;
    
    IF mismatch_count > 0 THEN
        RAISE NOTICE '';
        RAISE NOTICE '--- WARNING: RESULT COUNT MISMATCHES ---';
    END IF;
END $$;

SELECT 
    pattern_type,
    pattern,
    trgm_count,
    biscuit_count,
    ABS(trgm_count - biscuit_count) AS difference
FROM performance_comparison
WHERE trgm_count != biscuit_count
ORDER BY difference DESC
LIMIT 10;

DO $$ BEGIN RAISE NOTICE ''; END $$;
DO $$ BEGIN RAISE NOTICE '============================================'; END $$;
DO $$ BEGIN RAISE NOTICE '         BENCHMARK COMPLETE!'; END $$;
DO $$ BEGIN RAISE NOTICE '============================================'; END $$;

-- Turn off timing
-- \timing off