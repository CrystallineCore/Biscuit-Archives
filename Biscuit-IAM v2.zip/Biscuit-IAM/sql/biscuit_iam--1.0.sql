-- biscuit_iam.sql
-- SQL installation script for Biscuit IAM
-- PostgreSQL 16+ compatible

-- Create the index access method handler function
CREATE FUNCTION biscuit_handler(internal)
RETURNS index_am_handler
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT;

-- Create the index access method
CREATE ACCESS METHOD biscuit TYPE INDEX HANDLER biscuit_handler;

-- Create operator class for text (default) - this handles text, varchar, and bpchar
CREATE OPERATOR CLASS biscuit_text_ops
DEFAULT FOR TYPE text USING biscuit AS
    OPERATOR 1 ~~ (text, text),
    FUNCTION 1 hashtext(text);

COMMENT ON ACCESS METHOD biscuit IS 'Biscuit index access method for efficient pattern matching on text columns';
COMMENT ON FUNCTION biscuit_handler(internal) IS 'Index access method handler for Biscuit indexes';
COMMENT ON OPERATOR CLASS biscuit_text_ops USING biscuit IS 'Operator class for text pattern matching with Biscuit indexes';