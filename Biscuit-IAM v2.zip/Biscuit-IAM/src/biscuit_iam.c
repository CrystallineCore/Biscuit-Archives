/*
 * biscuit_iam.c
 * PostgreSQL Index Access Method for Biscuit Pattern Matching
 * 
 * Usage: CREATE INDEX idx_name ON table USING biscuit(column);
 */

 #include "postgres.h"
 #include "access/amapi.h"
 #include "access/generic_xlog.h"
 #include "access/reloptions.h"
 #include "access/relscan.h"
 #include "access/tableam.h"
 #include "access/table.h"
 #include "catalog/index.h"
 #include "miscadmin.h"
 #include "nodes/pathnodes.h"
 #include "optimizer/optimizer.h"
 #include "storage/bufmgr.h"
 #include "storage/indexfsm.h"
 #include "storage/lmgr.h"
 #include "utils/builtins.h"
 #include "utils/memutils.h"
 #include "utils/rel.h"
 
 #ifdef HAVE_ROARING
 #include "roaring.h"
 typedef roaring_bitmap_t RoaringBitmap;
 #else
 typedef struct {
     uint64_t *blocks;
     int num_blocks;
     int capacity;
 } RoaringBitmap;
 #endif
 
 PG_MODULE_MAGIC;
 
 /* Forward declarations */
 PG_FUNCTION_INFO_V1(biscuit_handler);
 
 /* Index metapage and page structures */
 #define BISCUIT_MAGIC 0x42495343  /* "BISC" */
 #define BISCUIT_VERSION 1
 #define BISCUIT_METAPAGE_BLKNO 0
 #define MAX_POSITIONS 256
 #define CHAR_RANGE 256
 
 typedef struct BiscuitMetaPageData {
     uint32 magic;
     uint32 version;
     BlockNumber root;
     uint32 num_records;
 } BiscuitMetaPageData;
 
 typedef BiscuitMetaPageData *BiscuitMetaPage;
 
 /* Position entry for character indices */
 typedef struct {
     int pos;
     RoaringBitmap *bitmap;
 } PosEntry;
 
 typedef struct {
     PosEntry *entries;
     int count;
     int capacity;
 } CharIndex;
 
 /* In-memory index structure */
 typedef struct {
     CharIndex pos_idx[CHAR_RANGE];
     CharIndex neg_idx[CHAR_RANGE];
     RoaringBitmap *char_cache[CHAR_RANGE];
     RoaringBitmap **length_bitmaps;
     RoaringBitmap **length_ge_bitmaps;
     int max_length;
     int max_len;
     ItemPointerData *tids;
     int num_records;
     int capacity;
 } BiscuitIndex;
 
 /* Scan opaque structure */
 typedef struct {
     BiscuitIndex *index;
     ItemPointerData *results;
     int num_results;
     int current;
 } BiscuitScanOpaque;
 
 /* ==================== ROARING BITMAP WRAPPER ==================== */
 
 #ifdef HAVE_ROARING
 static inline RoaringBitmap* biscuit_roaring_create(void) { return roaring_bitmap_create(); }
 static inline void biscuit_roaring_add(RoaringBitmap *rb, uint32_t value) { roaring_bitmap_add(rb, value); }
 static inline uint64_t biscuit_roaring_count(const RoaringBitmap *rb) { return roaring_bitmap_get_cardinality(rb); }
 static inline bool biscuit_roaring_is_empty(const RoaringBitmap *rb) { return roaring_bitmap_get_cardinality(rb) == 0; }
 static inline void biscuit_roaring_free(RoaringBitmap *rb) { if (rb) roaring_bitmap_free(rb); }
 static inline RoaringBitmap* biscuit_roaring_copy(const RoaringBitmap *rb) { return roaring_bitmap_copy(rb); }
 static inline void biscuit_roaring_and_inplace(RoaringBitmap *a, const RoaringBitmap *b) { roaring_bitmap_and_inplace(a, b); }
 static inline void biscuit_roaring_or_inplace(RoaringBitmap *a, const RoaringBitmap *b) { roaring_bitmap_or_inplace(a, b); }
 static inline void biscuit_roaring_andnot_inplace(RoaringBitmap *a, const RoaringBitmap *b) { roaring_bitmap_andnot_inplace(a, b); }
 
 static inline uint32_t* biscuit_roaring_to_array(const RoaringBitmap *rb, uint64_t *count) {
     uint32_t *array;
     *count = roaring_bitmap_get_cardinality(rb);
     if (*count == 0) return NULL;
     array = (uint32_t *)palloc(*count * sizeof(uint32_t));
     roaring_bitmap_to_uint32_array(rb, array);
     return array;
 }
 #else
 static inline RoaringBitmap* biscuit_roaring_create(void) {
     RoaringBitmap *rb = (RoaringBitmap *)palloc0(sizeof(RoaringBitmap));
     rb->capacity = 16;
     rb->blocks = (uint64_t *)palloc0(rb->capacity * sizeof(uint64_t));
     return rb;
 }
 
 static inline void biscuit_roaring_add(RoaringBitmap *rb, uint32_t value) {
     int block = value >> 6;
     int bit = value & 63;
     if (block >= rb->capacity) {
         int new_cap = (block + 1) * 2;
         uint64_t *new_blocks = (uint64_t *)palloc0(new_cap * sizeof(uint64_t));
         if (rb->num_blocks > 0)
             memcpy(new_blocks, rb->blocks, rb->num_blocks * sizeof(uint64_t));
         pfree(rb->blocks);
         rb->blocks = new_blocks;
         rb->capacity = new_cap;
     }
     if (block >= rb->num_blocks)
         rb->num_blocks = block + 1;
     rb->blocks[block] |= (1ULL << bit);
 }
 
 static inline uint64_t biscuit_roaring_count(const RoaringBitmap *rb) {
     uint64_t count = 0;
     int i;
     for (i = 0; i < rb->num_blocks; i++)
         count += __builtin_popcountll(rb->blocks[i]);
     return count;
 }
 
 static inline bool biscuit_roaring_is_empty(const RoaringBitmap *rb) {
     int i;
     for (i = 0; i < rb->num_blocks; i++)
         if (rb->blocks[i]) return false;
     return true;
 }
 
 static inline void biscuit_roaring_free(RoaringBitmap *rb) {
     if (rb) {
         if (rb->blocks) pfree(rb->blocks);
         pfree(rb);
     }
 }
 
 static inline RoaringBitmap* biscuit_roaring_copy(const RoaringBitmap *rb) {
     RoaringBitmap *copy = biscuit_roaring_create();
     if (rb->num_blocks > 0) {
         pfree(copy->blocks);
         copy->blocks = (uint64_t *)palloc(rb->num_blocks * sizeof(uint64_t));
         copy->num_blocks = rb->num_blocks;
         copy->capacity = rb->num_blocks;
         memcpy(copy->blocks, rb->blocks, rb->num_blocks * sizeof(uint64_t));
     }
     return copy;
 }
 
 static inline void biscuit_roaring_and_inplace(RoaringBitmap *a, const RoaringBitmap *b) {
     int min = (a->num_blocks < b->num_blocks) ? a->num_blocks : b->num_blocks;
     int i;
     for (i = 0; i < min; i++)
         a->blocks[i] &= b->blocks[i];
     for (i = min; i < a->num_blocks; i++)
         a->blocks[i] = 0;
     a->num_blocks = min;
 }
 
 static inline void biscuit_roaring_or_inplace(RoaringBitmap *a, const RoaringBitmap *b) {
     int min;
     int i;
     if (b->num_blocks > a->capacity) {
         uint64_t *new_blocks = (uint64_t *)palloc0(b->num_blocks * sizeof(uint64_t));
         if (a->num_blocks > 0)
             memcpy(new_blocks, a->blocks, a->num_blocks * sizeof(uint64_t));
         pfree(a->blocks);
         a->blocks = new_blocks;
         a->capacity = b->num_blocks;
     }
     min = (a->num_blocks < b->num_blocks) ? a->num_blocks : b->num_blocks;
     for (i = 0; i < min; i++)
         a->blocks[i] |= b->blocks[i];
     if (b->num_blocks > a->num_blocks) {
         memcpy(a->blocks + a->num_blocks, b->blocks + a->num_blocks,
                (b->num_blocks - a->num_blocks) * sizeof(uint64_t));
         a->num_blocks = b->num_blocks;
     }
 }
 
 static inline void biscuit_roaring_andnot_inplace(RoaringBitmap *a, const RoaringBitmap *b) {
     int min = (a->num_blocks < b->num_blocks) ? a->num_blocks : b->num_blocks;
     int i;
     for (i = 0; i < min; i++)
         a->blocks[i] &= ~b->blocks[i];
 }
 
 static inline uint32_t* biscuit_roaring_to_array(const RoaringBitmap *rb, uint64_t *count) {
     uint32_t *array;
     int idx;
     int i;
     uint64_t base;
     *count = biscuit_roaring_count(rb);
     if (*count == 0) return NULL;
     array = (uint32_t *)palloc(*count * sizeof(uint32_t));
     idx = 0;
     for (i = 0; i < rb->num_blocks; i++) {
         uint64_t bits = rb->blocks[i];
         if (!bits) continue;
         base = (uint64_t)i << 6;
         while (bits) {
             array[idx++] = (uint32_t)(base + __builtin_ctzll(bits));
             bits &= bits - 1;
         }
     }
     return array;
 }
 #endif
 
 /* ==================== BITMAP ACCESS ==================== */
 
 static inline RoaringBitmap* biscuit_get_pos_bitmap(BiscuitIndex *idx, unsigned char ch, int pos) {
     CharIndex *cidx = &idx->pos_idx[ch];
     int left = 0, right = cidx->count - 1;
     while (left <= right) {
         int mid = (left + right) >> 1;
         if (cidx->entries[mid].pos == pos)
             return cidx->entries[mid].bitmap;
         else if (cidx->entries[mid].pos < pos)
             left = mid + 1;
         else
             right = mid - 1;
     }
     return NULL;
 }
 
 static inline RoaringBitmap* biscuit_get_neg_bitmap(BiscuitIndex *idx, unsigned char ch, int neg_offset) {
     CharIndex *cidx = &idx->neg_idx[ch];
     int left = 0, right = cidx->count - 1;
     while (left <= right) {
         int mid = (left + right) >> 1;
         if (cidx->entries[mid].pos == neg_offset)
             return cidx->entries[mid].bitmap;
         else if (cidx->entries[mid].pos < neg_offset)
             left = mid + 1;
         else
             right = mid - 1;
     }
     return NULL;
 }
 
 static void biscuit_set_pos_bitmap(BiscuitIndex *idx, unsigned char ch, int pos, RoaringBitmap *bm) {
     CharIndex *cidx = &idx->pos_idx[ch];
     int left = 0, right = cidx->count - 1, insert_pos = cidx->count;
     int i;
     
     while (left <= right) {
         int mid = (left + right) >> 1;
         if (cidx->entries[mid].pos == pos) {
             cidx->entries[mid].bitmap = bm;
             return;
         } else if (cidx->entries[mid].pos < pos)
             left = mid + 1;
         else {
             insert_pos = mid;
             right = mid - 1;
         }
     }
     
     if (cidx->count >= cidx->capacity) {
         int new_cap = cidx->capacity * 2;
         PosEntry *new_entries = (PosEntry *)palloc(new_cap * sizeof(PosEntry));
         if (cidx->count > 0)
             memcpy(new_entries, cidx->entries, cidx->count * sizeof(PosEntry));
         pfree(cidx->entries);
         cidx->entries = new_entries;
         cidx->capacity = new_cap;
     }
     
     for (i = cidx->count; i > insert_pos; i--)
         cidx->entries[i] = cidx->entries[i - 1];
     
     cidx->entries[insert_pos].pos = pos;
     cidx->entries[insert_pos].bitmap = bm;
     cidx->count++;
 }
 
 static void biscuit_set_neg_bitmap(BiscuitIndex *idx, unsigned char ch, int neg_offset, RoaringBitmap *bm) {
     CharIndex *cidx = &idx->neg_idx[ch];
     int left = 0, right = cidx->count - 1, insert_pos = cidx->count;
     int i;
     
     while (left <= right) {
         int mid = (left + right) >> 1;
         if (cidx->entries[mid].pos == neg_offset) {
             cidx->entries[mid].bitmap = bm;
             return;
         } else if (cidx->entries[mid].pos < neg_offset)
             left = mid + 1;
         else {
             insert_pos = mid;
             right = mid - 1;
         }
     }
     
     if (cidx->count >= cidx->capacity) {
         int new_cap = cidx->capacity * 2;
         PosEntry *new_entries = (PosEntry *)palloc(new_cap * sizeof(PosEntry));
         if (cidx->count > 0)
             memcpy(new_entries, cidx->entries, cidx->count * sizeof(PosEntry));
         pfree(cidx->entries);
         cidx->entries = new_entries;
         cidx->capacity = new_cap;
     }
     
     for (i = cidx->count; i > insert_pos; i--)
         cidx->entries[i] = cidx->entries[i - 1];
     
     cidx->entries[insert_pos].pos = neg_offset;
     cidx->entries[insert_pos].bitmap = bm;
     cidx->count++;
 }
 
 /* ==================== PATTERN MATCHING ==================== */
 
 static RoaringBitmap* biscuit_get_length_ge(BiscuitIndex *idx, int min_len) {
     if (min_len >= idx->max_length)
         return biscuit_roaring_create();
     return biscuit_roaring_copy(idx->length_ge_bitmaps[min_len]);
 }
 
 static RoaringBitmap* biscuit_match_part_at_pos(BiscuitIndex *idx, const char *part, int part_len, int start_pos) {
     RoaringBitmap *result = NULL;
     int i;
     for (i = 0; i < part_len; i++) {
         RoaringBitmap *char_bm;
         if (part[i] == '_') {
             int ch;
             char_bm = biscuit_roaring_create();
             for (ch = 0; ch < CHAR_RANGE; ch++) {
                 RoaringBitmap *cb = biscuit_get_pos_bitmap(idx, ch, start_pos + i);
                 if (cb) biscuit_roaring_or_inplace(char_bm, cb);
             }
         } else {
             char_bm = biscuit_get_pos_bitmap(idx, (unsigned char)part[i], start_pos + i);
             if (!char_bm) {
                 if (result) biscuit_roaring_free(result);
                 return biscuit_roaring_create();
             }
             char_bm = biscuit_roaring_copy(char_bm);
         }
         if (!result)
             result = char_bm;
         else {
             biscuit_roaring_and_inplace(result, char_bm);
             biscuit_roaring_free(char_bm);
             if (biscuit_roaring_is_empty(result))
                 return result;
         }
     }
     return result ? result : biscuit_roaring_create();
 }
 
 static RoaringBitmap* biscuit_match_part_at_end(BiscuitIndex *idx, const char *part, int part_len) {
     RoaringBitmap *result = NULL;
     int i;
     for (i = 0; i < part_len; i++) {
         int neg_pos = -(part_len - i);
         RoaringBitmap *char_bm;
         if (part[i] == '_') {
             int ch;
             char_bm = biscuit_roaring_create();
             for (ch = 0; ch < CHAR_RANGE; ch++) {
                 RoaringBitmap *cb = biscuit_get_neg_bitmap(idx, ch, neg_pos);
                 if (cb) biscuit_roaring_or_inplace(char_bm, cb);
             }
         } else {
             char_bm = biscuit_get_neg_bitmap(idx, (unsigned char)part[i], neg_pos);
             if (!char_bm) {
                 if (result) biscuit_roaring_free(result);
                 return biscuit_roaring_create();
             }
             char_bm = biscuit_roaring_copy(char_bm);
         }
         if (!result)
             result = char_bm;
         else {
             biscuit_roaring_and_inplace(result, char_bm);
             biscuit_roaring_free(char_bm);
             if (biscuit_roaring_is_empty(result))
                 return result;
         }
     }
     return result ? result : biscuit_roaring_create();
 }
 
 typedef struct {
     char **parts;
     int *part_lens;
     int part_count;
     bool starts_percent;
     bool ends_percent;
 } ParsedPattern;
 
 static ParsedPattern* biscuit_parse_pattern(const char *pattern) {
     ParsedPattern *parsed;
     int plen;
     int part_cap = 8;
     int part_start;
     int i;
     
     parsed = (ParsedPattern *)palloc(sizeof(ParsedPattern));
     plen = strlen(pattern);
     
     parsed->parts = (char **)palloc(part_cap * sizeof(char *));
     parsed->part_lens = (int *)palloc(part_cap * sizeof(int));
     parsed->part_count = 0;
     parsed->starts_percent = (plen > 0 && pattern[0] == '%');
     parsed->ends_percent = (plen > 0 && pattern[plen - 1] == '%');
     
     part_start = parsed->starts_percent ? 1 : 0;
     
     for (i = part_start; i < plen; i++) {
         if (pattern[i] == '%') {
             int part_len = i - part_start;
             if (part_len > 0) {
                 if (parsed->part_count >= part_cap) {
                     int new_cap = part_cap * 2;
                     char **new_parts = (char **)palloc(new_cap * sizeof(char *));
                     int *new_lens = (int *)palloc(new_cap * sizeof(int));
                     memcpy(new_parts, parsed->parts, part_cap * sizeof(char *));
                     memcpy(new_lens, parsed->part_lens, part_cap * sizeof(int));
                     pfree(parsed->parts);
                     pfree(parsed->part_lens);
                     parsed->parts = new_parts;
                     parsed->part_lens = new_lens;
                     part_cap = new_cap;
                 }
                 parsed->parts[parsed->part_count] = pnstrdup(pattern + part_start, part_len);
                 parsed->part_lens[parsed->part_count] = part_len;
                 parsed->part_count++;
             }
             part_start = i + 1;
         }
     }
     
     if (part_start < plen && (!parsed->ends_percent || part_start < plen - 1)) {
         int part_len = parsed->ends_percent ? (plen - 1 - part_start) : (plen - part_start);
         if (part_len > 0) {
             parsed->parts[parsed->part_count] = pnstrdup(pattern + part_start, part_len);
             parsed->part_lens[parsed->part_count] = part_len;
             parsed->part_count++;
         }
     }
     
     return parsed;
 }
 
 static void biscuit_recursive_windowed_match(
     RoaringBitmap *result, BiscuitIndex *idx,
     const char **parts, int *part_lens, int part_count,
     bool ends_percent, int part_idx, int min_pos,
     RoaringBitmap *current_candidates, int max_len)
 {
     int remaining_len = 0;
     int i;
     int max_pos;
     int pos;
     
     if (part_idx >= part_count) {
         biscuit_roaring_or_inplace(result, current_candidates);
         return;
     }
     
     for (i = part_idx + 1; i < part_count; i++)
         remaining_len += part_lens[i];
     
     if (part_idx == part_count - 1 && !ends_percent) {
         RoaringBitmap *last_match = biscuit_match_part_at_end(idx, parts[part_idx], part_lens[part_idx]);
         biscuit_roaring_and_inplace(last_match, current_candidates);
         biscuit_roaring_or_inplace(result, last_match);
         biscuit_roaring_free(last_match);
         return;
     }
     
     max_pos = max_len - part_lens[part_idx] - remaining_len;
     if (min_pos > max_pos) return;
     
     for (pos = min_pos; pos <= max_pos; pos++) {
         RoaringBitmap *part_at_pos = biscuit_match_part_at_pos(idx, parts[part_idx], part_lens[part_idx], pos);
         biscuit_roaring_and_inplace(part_at_pos, current_candidates);
         if (!biscuit_roaring_is_empty(part_at_pos)) {
             biscuit_recursive_windowed_match(result, idx, parts, part_lens, part_count, ends_percent,
                                     part_idx + 1, pos + part_lens[part_idx], part_at_pos, max_len);
         }
         biscuit_roaring_free(part_at_pos);
     }
 }
 
 static RoaringBitmap* biscuit_query_pattern(BiscuitIndex *idx, const char *pattern) {
     int plen;
     ParsedPattern *parsed;
     int min_len;
     RoaringBitmap *result;
     int i;
     
     plen = strlen(pattern);
     
     if (plen == 0) {
         if (idx->max_length > 0 && idx->length_bitmaps[0])
             return biscuit_roaring_copy(idx->length_bitmaps[0]);
         return biscuit_roaring_create();
     }
     
     if (plen == 1 && pattern[0] == '%') {
         result = biscuit_roaring_create();
         for (i = 0; i < idx->num_records; i++)
             biscuit_roaring_add(result, i);
         return result;
     }
     
     parsed = biscuit_parse_pattern(pattern);
     
     if (parsed->part_count == 0) {
         result = biscuit_roaring_create();
         for (i = 0; i < idx->num_records; i++)
             biscuit_roaring_add(result, i);
         pfree(parsed->parts);
         pfree(parsed->part_lens);
         pfree(parsed);
         return result;
     }
     
     min_len = 0;
     for (i = 0; i < parsed->part_count; i++)
         min_len += parsed->part_lens[i];
     
     if (parsed->part_count == 1) {
         if (!parsed->starts_percent && !parsed->ends_percent) {
             RoaringBitmap *len_filter;
             result = biscuit_match_part_at_pos(idx, parsed->parts[0], parsed->part_lens[0], 0);
             if (min_len < idx->max_length && idx->length_bitmaps[min_len]) {
                 len_filter = biscuit_roaring_copy(idx->length_bitmaps[min_len]);
                 biscuit_roaring_and_inplace(result, len_filter);
                 biscuit_roaring_free(len_filter);
             }
         } else if (!parsed->starts_percent) {
             RoaringBitmap *len_filter;
             result = biscuit_match_part_at_pos(idx, parsed->parts[0], parsed->part_lens[0], 0);
             len_filter = biscuit_get_length_ge(idx, min_len);
             biscuit_roaring_and_inplace(result, len_filter);
             biscuit_roaring_free(len_filter);
         } else if (!parsed->ends_percent) {
             RoaringBitmap *len_filter;
             result = biscuit_match_part_at_end(idx, parsed->parts[0], parsed->part_lens[0]);
             len_filter = biscuit_get_length_ge(idx, min_len);
             biscuit_roaring_and_inplace(result, len_filter);
             biscuit_roaring_free(len_filter);
         } else {
             int pos;
             result = biscuit_roaring_create();
             for (pos = 0; pos <= idx->max_len - parsed->part_lens[0]; pos++) {
                 RoaringBitmap *match = biscuit_match_part_at_pos(idx, parsed->parts[0], parsed->part_lens[0], pos);
                 biscuit_roaring_or_inplace(result, match);
                 biscuit_roaring_free(match);
             }
         }
     } else {
         RoaringBitmap *initial = biscuit_get_length_ge(idx, min_len);
         result = biscuit_roaring_create();
         biscuit_recursive_windowed_match(result, idx, (const char **)parsed->parts, parsed->part_lens,
                                 parsed->part_count, parsed->ends_percent, 0, 0, initial, idx->max_len);
         biscuit_roaring_free(initial);
     }
     
     for (i = 0; i < parsed->part_count; i++)
         pfree(parsed->parts[i]);
     pfree(parsed->parts);
     pfree(parsed->part_lens);
     pfree(parsed);
     
     return result;
 }
 
 /* ==================== IAM CALLBACK FUNCTIONS ==================== */
 
 static IndexBuildResult *
 biscuit_build(Relation heap, Relation index, IndexInfo *indexInfo)
 {
     IndexBuildResult *result;
     BiscuitIndex *idx;
     TableScanDesc scan;
     TupleTableSlot *slot;
     Datum values[1];
     bool isnull[1];
     int natts;
     int ch;
     int rec_idx;
     MemoryContext oldcontext;
     MemoryContext indexContext;
     
     natts = indexInfo->ii_NumIndexAttrs;
     
     if (natts != 1)
         ereport(ERROR, (errcode(ERRCODE_FEATURE_NOT_SUPPORTED),
                 errmsg("biscuit index supports only one column")));
     
     /* Create persistent memory context for index */
     if (!index->rd_indexcxt) {
         index->rd_indexcxt = AllocSetContextCreate(CacheMemoryContext,
                                                     "Biscuit index context",
                                                     ALLOCSET_DEFAULT_SIZES);
     }
     indexContext = index->rd_indexcxt;
     oldcontext = MemoryContextSwitchTo(indexContext);
     
     /* Initialize in-memory index */
     idx = (BiscuitIndex *)palloc0(sizeof(BiscuitIndex));
     idx->capacity = 1024;
     idx->num_records = 0;
     idx->tids = (ItemPointerData *)palloc(idx->capacity * sizeof(ItemPointerData));
     idx->max_len = 0;
     
     for (ch = 0; ch < CHAR_RANGE; ch++) {
         idx->pos_idx[ch].entries = (PosEntry *)palloc(64 * sizeof(PosEntry));
         idx->pos_idx[ch].count = 0;
         idx->pos_idx[ch].capacity = 64;
         idx->neg_idx[ch].entries = (PosEntry *)palloc(64 * sizeof(PosEntry));
         idx->neg_idx[ch].count = 0;
         idx->neg_idx[ch].capacity = 64;
         idx->char_cache[ch] = NULL;
     }
     
     MemoryContextSwitchTo(oldcontext);
     
     /* Scan heap and build index */
     slot = table_slot_create(heap, NULL);
     scan = table_beginscan(heap, SnapshotAny, 0, NULL);
     
     elog(INFO, "Biscuit: Starting index build on relation %s", RelationGetRelationName(heap));
     
     while (table_scan_getnextslot(scan, ForwardScanDirection, slot)) {
         int pos;
         text *txt;
         char *str;
         int len;
         bool should_free;
         
         slot_getallattrs(slot);
         
         /* Get the indexed column value from the heap tuple */
         values[0] = slot_getattr(slot, indexInfo->ii_IndexAttrNumbers[0], &isnull[0]);
         
         if (!isnull[0]) {
             txt = DatumGetTextPP(values[0]);
             str = VARDATA_ANY(txt);
             len = VARSIZE_ANY_EXHDR(txt);
             should_free = (txt != DatumGetTextPP(values[0]));
             
             if (len > MAX_POSITIONS) len = MAX_POSITIONS;
             if (len > idx->max_len) idx->max_len = len;
             
             /* Switch to index context for allocations */
             oldcontext = MemoryContextSwitchTo(indexContext);
             
             /* Add to TID list */
             if (idx->num_records >= idx->capacity) {
                 idx->capacity *= 2;
                 idx->tids = (ItemPointerData *)repalloc(idx->tids, idx->capacity * sizeof(ItemPointerData));
             }
             ItemPointerCopy(&slot->tts_tid, &idx->tids[idx->num_records]);
             
             /* Build bitmaps */
             for (pos = 0; pos < len; pos++) {
                 unsigned char uch = (unsigned char)str[pos];
                 RoaringBitmap *bm;
                 int neg_offset;
                 
                 bm = biscuit_get_pos_bitmap(idx, uch, pos);
                 if (!bm) {
                     bm = biscuit_roaring_create();
                     biscuit_set_pos_bitmap(idx, uch, pos, bm);
                 }
                 biscuit_roaring_add(bm, idx->num_records);
                 
                 neg_offset = -(len - pos);
                 bm = biscuit_get_neg_bitmap(idx, uch, neg_offset);
                 if (!bm) {
                     bm = biscuit_roaring_create();
                     biscuit_set_neg_bitmap(idx, uch, neg_offset, bm);
                 }
                 biscuit_roaring_add(bm, idx->num_records);
                 
                 if (!idx->char_cache[uch])
                     idx->char_cache[uch] = biscuit_roaring_create();
                 biscuit_roaring_add(idx->char_cache[uch], idx->num_records);
             }
             
             idx->num_records++;
             
             MemoryContextSwitchTo(oldcontext);
             
             if (should_free)
                 pfree(txt);
         }
     }
     
     table_endscan(scan);
     ExecDropSingleTupleTableSlot(slot);
     
     elog(INFO, "Biscuit: Indexed %d records, max_len=%d", idx->num_records, idx->max_len);
     
     /* Switch to index context for remaining allocations */
     oldcontext = MemoryContextSwitchTo(indexContext);
     
     /* Build length bitmaps */
     idx->max_length = idx->max_len + 1;
     idx->length_bitmaps = (RoaringBitmap **)palloc0(idx->max_length * sizeof(RoaringBitmap *));
     idx->length_ge_bitmaps = (RoaringBitmap **)palloc0((idx->max_length + 1) * sizeof(RoaringBitmap *));
     
     for (ch = 0; ch <= idx->max_length; ch++)
         idx->length_ge_bitmaps[ch] = biscuit_roaring_create();
     
     MemoryContextSwitchTo(oldcontext);
     
     /* Rescan to build length bitmaps */
     slot = table_slot_create(heap, NULL);
     scan = table_beginscan(heap, SnapshotAny, 0, NULL);
     rec_idx = 0;
     
     while (table_scan_getnextslot(scan, ForwardScanDirection, slot)) {
         text *txt;
         char *str;
         int len;
         int i;
         bool should_free;
         
         slot_getallattrs(slot);
         
         /* Get the indexed column value from the heap tuple */
         values[0] = slot_getattr(slot, indexInfo->ii_IndexAttrNumbers[0], &isnull[0]);
         
         if (!isnull[0]) {
             txt = DatumGetTextPP(values[0]);
             str = VARDATA_ANY(txt);
             len = VARSIZE_ANY_EXHDR(txt);
             should_free = (txt != DatumGetTextPP(values[0]));
             
             oldcontext = MemoryContextSwitchTo(indexContext);
             
             if (len < idx->max_length) {
                 if (!idx->length_bitmaps[len])
                     idx->length_bitmaps[len] = biscuit_roaring_create();
                 biscuit_roaring_add(idx->length_bitmaps[len], rec_idx);
             }
             
             for (i = 0; i <= len && i < idx->max_length; i++)
                 biscuit_roaring_add(idx->length_ge_bitmaps[i], rec_idx);
             
             MemoryContextSwitchTo(oldcontext);
             
             rec_idx++;
             if (should_free)
                 pfree(txt);
         }
     }
     
     table_endscan(scan);
     ExecDropSingleTupleTableSlot(slot);
     
     /* Store index in relation cache */
     index->rd_amcache = idx;
     
     elog(INFO, "Biscuit: Index build complete, stored in rd_amcache");
     
     result = (IndexBuildResult *)palloc(sizeof(IndexBuildResult));
     result->heap_tuples = idx->num_records;
     result->index_tuples = idx->num_records;
     
     return result;
 }

 /* Helper function to rebuild index from disk */
static BiscuitIndex* biscuit_load_index(Relation index)
{
    Relation heap;
    TableScanDesc scan;
    TupleTableSlot *slot;
    BiscuitIndex *idx;
    MemoryContext oldcontext;
    MemoryContext indexContext;
    int ch;
    int rec_idx;
    AttrNumber indexcol;
    
    elog(INFO, "Biscuit: Loading index from heap");
    
    /* Get the heap relation */
    heap = table_open(index->rd_index->indrelid, AccessShareLock);
    
    /* Get the indexed column number */
    indexcol = index->rd_index->indkey.values[0];
    
    /* Create persistent memory context for index */
    if (!index->rd_indexcxt) {
        index->rd_indexcxt = AllocSetContextCreate(CacheMemoryContext,
                                                    "Biscuit index context",
                                                    ALLOCSET_DEFAULT_SIZES);
    }
    indexContext = index->rd_indexcxt;
    oldcontext = MemoryContextSwitchTo(indexContext);
    
    /* Initialize in-memory index */
    idx = (BiscuitIndex *)palloc0(sizeof(BiscuitIndex));
    idx->capacity = 1024;
    idx->num_records = 0;
    idx->tids = (ItemPointerData *)palloc(idx->capacity * sizeof(ItemPointerData));
    idx->max_len = 0;
    
    for (ch = 0; ch < CHAR_RANGE; ch++) {
        idx->pos_idx[ch].entries = (PosEntry *)palloc(64 * sizeof(PosEntry));
        idx->pos_idx[ch].count = 0;
        idx->pos_idx[ch].capacity = 64;
        idx->neg_idx[ch].entries = (PosEntry *)palloc(64 * sizeof(PosEntry));
        idx->neg_idx[ch].count = 0;
        idx->neg_idx[ch].capacity = 64;
        idx->char_cache[ch] = NULL;
    }
    
    MemoryContextSwitchTo(oldcontext);
    
    /* Scan heap and build index */
    slot = table_slot_create(heap, NULL);
    scan = table_beginscan(heap, SnapshotAny, 0, NULL);
    
    while (table_scan_getnextslot(scan, ForwardScanDirection, slot)) {
        int pos;
        text *txt;
        char *str;
        int len;
        bool isnull;
        bool should_free;
        Datum value;
        
        slot_getallattrs(slot);
        
        /* Get the indexed column value - use attribute number from index definition */
        value = slot_getattr(slot, indexcol, &isnull);
        
        if (!isnull) {
            txt = DatumGetTextPP(value);
            str = VARDATA_ANY(txt);
            len = VARSIZE_ANY_EXHDR(txt);
            should_free = (txt != DatumGetTextPP(value));
            
            if (len > MAX_POSITIONS) len = MAX_POSITIONS;
            if (len > idx->max_len) idx->max_len = len;
            
            /* Switch to index context for allocations */
            oldcontext = MemoryContextSwitchTo(indexContext);
            
            /* Add to TID list */
            if (idx->num_records >= idx->capacity) {
                idx->capacity *= 2;
                idx->tids = (ItemPointerData *)repalloc(idx->tids, idx->capacity * sizeof(ItemPointerData));
            }
            ItemPointerCopy(&slot->tts_tid, &idx->tids[idx->num_records]);
            
            /* Build bitmaps */
            for (pos = 0; pos < len; pos++) {
                unsigned char uch = (unsigned char)str[pos];
                RoaringBitmap *bm;
                int neg_offset;
                
                bm = biscuit_get_pos_bitmap(idx, uch, pos);
                if (!bm) {
                    bm = biscuit_roaring_create();
                    biscuit_set_pos_bitmap(idx, uch, pos, bm);
                }
                biscuit_roaring_add(bm, idx->num_records);
                
                neg_offset = -(len - pos);
                bm = biscuit_get_neg_bitmap(idx, uch, neg_offset);
                if (!bm) {
                    bm = biscuit_roaring_create();
                    biscuit_set_neg_bitmap(idx, uch, neg_offset, bm);
                }
                biscuit_roaring_add(bm, idx->num_records);
                
                if (!idx->char_cache[uch])
                    idx->char_cache[uch] = biscuit_roaring_create();
                biscuit_roaring_add(idx->char_cache[uch], idx->num_records);
            }
            
            idx->num_records++;
            
            MemoryContextSwitchTo(oldcontext);
            
            if (should_free)
                pfree(txt);
        }
    }
    
    table_endscan(scan);
    ExecDropSingleTupleTableSlot(slot);
    
    elog(INFO, "Biscuit: Loaded %d records from heap, max_len=%d", idx->num_records, idx->max_len);
    
    /* Switch to index context for remaining allocations */
    oldcontext = MemoryContextSwitchTo(indexContext);
    
    /* Build length bitmaps */
    idx->max_length = idx->max_len + 1;
    idx->length_bitmaps = (RoaringBitmap **)palloc0(idx->max_length * sizeof(RoaringBitmap *));
    idx->length_ge_bitmaps = (RoaringBitmap **)palloc0((idx->max_length + 1) * sizeof(RoaringBitmap *));
    
    for (ch = 0; ch <= idx->max_length; ch++)
        idx->length_ge_bitmaps[ch] = biscuit_roaring_create();
    
    MemoryContextSwitchTo(oldcontext);
    
    /* Rescan to build length bitmaps */
    slot = table_slot_create(heap, NULL);
    scan = table_beginscan(heap, SnapshotAny, 0, NULL);
    rec_idx = 0;
    
    while (table_scan_getnextslot(scan, ForwardScanDirection, slot)) {
        text *txt;
        char *str;
        int len;
        int i;
        bool isnull;
        bool should_free;
        Datum value;
        
        slot_getallattrs(slot);
        
        value = slot_getattr(slot, indexcol, &isnull);
        
        if (!isnull) {
            txt = DatumGetTextPP(value);
            str = VARDATA_ANY(txt);
            len = VARSIZE_ANY_EXHDR(txt);
            should_free = (txt != DatumGetTextPP(value));
            
            oldcontext = MemoryContextSwitchTo(indexContext);
            
            if (len < idx->max_length) {
                if (!idx->length_bitmaps[len])
                    idx->length_bitmaps[len] = biscuit_roaring_create();
                biscuit_roaring_add(idx->length_bitmaps[len], rec_idx);
            }
            
            for (i = 0; i <= len && i < idx->max_length; i++)
                biscuit_roaring_add(idx->length_ge_bitmaps[i], rec_idx);
            
            MemoryContextSwitchTo(oldcontext);
            
            rec_idx++;
            if (should_free)
                pfree(txt);
        }
    }
    
    table_endscan(scan);
    ExecDropSingleTupleTableSlot(slot);
    
    table_close(heap, AccessShareLock);
    
    elog(INFO, "Biscuit: Index load complete");
    
    return idx;
}


 static void
 biscuit_buildempty(Relation index)
 {
     /* Nothing to do for empty index */
 }
 
 static bool
 biscuit_insert(Relation index, Datum *values, bool *isnull,
                ItemPointer ht_ctid, Relation heapRel,
                IndexUniqueCheck checkUnique,
                bool indexUnchanged,
                IndexInfo *indexInfo)
 {
     /* For now, we rebuild on insert - production would do incremental */
     return true;
 }
 
 static IndexBulkDeleteResult *
 biscuit_bulkdelete(IndexVacuumInfo *info, IndexBulkDeleteResult *stats,
                    IndexBulkDeleteCallback callback, void *callback_state)
 {
     /* Simplified - production would handle deletes properly */
     return stats;
 }
 
 static IndexBulkDeleteResult *
 biscuit_vacuumcleanup(IndexVacuumInfo *info, IndexBulkDeleteResult *stats)
 {
     return stats;
 }
 
 static bool
 biscuit_canreturn(Relation index, int attno)
 {
     return false;
 }
 
 static void
biscuit_costestimate(PlannerInfo *root, IndexPath *path,
                     double loop_count, Cost *indexStartupCost,
                     Cost *indexTotalCost, Selectivity *indexSelectivity,
                     double *indexCorrelation, double *indexPages)
{
    Relation index = path->indexinfo->indexoid != InvalidOid ? 
                     index_open(path->indexinfo->indexoid, AccessShareLock) : NULL;
    BlockNumber numPages = 1;
    double numTuples = 100.0;
    
    if (index != NULL) {
        numPages = RelationGetNumberOfBlocks(index);
        if (numPages == 0)
            numPages = 1;
        index_close(index, AccessShareLock);
    }
    
    /* Set very low costs to encourage index usage */
    *indexStartupCost = 0.0;
    *indexTotalCost = 0.01 + (numPages * random_page_cost);
    *indexSelectivity = 0.01;
    *indexCorrelation = 1.0;
    
    if (indexPages)
        *indexPages = numPages;
}
 
 static bytea *
 biscuit_options(Datum reloptions, bool validate)
 {
     return NULL;
 }
 
 static bool
 biscuit_validate(Oid opclassoid)
 {
     return true;
 }
 
 static void
 biscuit_adjustmembers(Oid opfamilyoid, Oid opclassoid,
                       List *operators, List *functions)
 {
     /* Nothing to adjust */
 }
 
 static IndexScanDesc
 biscuit_beginscan(Relation index, int nkeys, int norderbys)
 {
     IndexScanDesc scan;
     BiscuitScanOpaque *so;
     
     scan = RelationGetIndexScan(index, nkeys, norderbys);
     
     so = (BiscuitScanOpaque *)palloc(sizeof(BiscuitScanOpaque));
     
     /* Try to get index from cache, load if not available */
     so->index = (BiscuitIndex *)index->rd_amcache;
     
     if (!so->index) {
         elog(INFO, "Biscuit index not in cache - loading from heap");
         so->index = biscuit_load_index(index);
         index->rd_amcache = so->index;
     }
     
     /* Debug logging */
     if (so->index) {
         elog(DEBUG1, "Biscuit index loaded: %d records, max_len=%d", 
              so->index->num_records, so->index->max_len);
     } else {
         elog(WARNING, "Biscuit index failed to load");
     }
     
     so->results = NULL;
     so->num_results = 0;
     so->current = 0;
     
     scan->opaque = so;
     
     return scan;
 }
 
 static void
 biscuit_rescan(IndexScanDesc scan, ScanKey keys, int nkeys,
                ScanKey orderbys, int norderbys)
 {
     BiscuitScanOpaque *so = (BiscuitScanOpaque *)scan->opaque;
     
     elog(DEBUG1, "Biscuit rescan called: nkeys=%d", nkeys);
     
     if (so->results) {
         pfree(so->results);
         so->results = NULL;
     }
     so->num_results = 0;
     so->current = 0;
     
     /* Check if index is available, load if needed */
     if (!so->index) {
         so->index = (BiscuitIndex *)scan->indexRelation->rd_amcache;
         if (!so->index) {
             elog(INFO, "Biscuit: Index not in cache during rescan - loading from heap");
             so->index = biscuit_load_index(scan->indexRelation);
             scan->indexRelation->rd_amcache = so->index;
         }
         if (!so->index) {
             elog(WARNING, "Biscuit: Index failed to load in rescan");
             return;
         }
     }
     
     elog(DEBUG1, "Biscuit: Index has %d records", so->index->num_records);
     
     if (nkeys > 0 && so->index && so->index->num_records > 0) {
         ScanKey key;
         text *pattern_text;
         char *pattern;
         RoaringBitmap *result;
         uint64_t count;
         uint32_t *indices;
         int i;
         
         key = &keys[0];
         
         elog(DEBUG1, "Biscuit: Key strategy=%d, flags=%d", key->sk_strategy, key->sk_flags);
         
         /* Check for NULL */
         if (key->sk_flags & SK_ISNULL) {
             elog(DEBUG1, "Biscuit: Key is NULL, returning no results");
             return;
         }
         
         /* Accept any strategy number - the planner knows what it's doing
          * Don't filter by strategy, just process the pattern
          */
         
         /* Extract pattern from scan key */
         pattern_text = DatumGetTextPP(key->sk_argument);
         pattern = text_to_cstring(pattern_text);
         
         elog(INFO, "Biscuit index searching for pattern: '%s'", pattern);
         
         /* Query using Biscuit engine */
         result = biscuit_query_pattern(so->index, pattern);
         
         if (!result) {
             elog(WARNING, "Biscuit: Query pattern returned NULL");
             pfree(pattern);
             return;
         }
         
         /* Get result count */
         count = biscuit_roaring_count(result);
         elog(INFO, "Biscuit index found %lu matches for pattern '%s'", (unsigned long)count, pattern);
         
         /* Convert bitmap to TID array */
         indices = biscuit_roaring_to_array(result, &count);
         
         if (indices && count > 0) {
             so->num_results = (int)count;
             so->results = (ItemPointerData *)palloc(count * sizeof(ItemPointerData));
             
             elog(DEBUG1, "Biscuit: Converting %d indices to TIDs", (int)count);
             
             for (i = 0; i < (int)count; i++) {
                 if (indices[i] < (uint32_t)so->index->num_records) {
                     ItemPointerCopy(&so->index->tids[indices[i]], &so->results[i]);
                     elog(DEBUG2, "Biscuit: Result %d -> TID (%u,%u)", 
                          i, ItemPointerGetBlockNumber(&so->results[i]),
                          ItemPointerGetOffsetNumber(&so->results[i]));
                 } else {
                     elog(WARNING, "Biscuit index: invalid record index %u (max %d)", 
                          indices[i], so->index->num_records);
                 }
             }
             
             pfree(indices);
             elog(INFO, "Biscuit: Prepared %d result TIDs", so->num_results);
         } else {
             elog(INFO, "Biscuit: No matches found or conversion failed");
         }
         
         biscuit_roaring_free(result);
         pfree(pattern);
     } else {
         elog(DEBUG1, "Biscuit: Skipping query - nkeys=%d, index=%p, num_records=%d",
              nkeys, so->index, so->index ? so->index->num_records : 0);
     }
 }
 
 static bool
 biscuit_gettuple(IndexScanDesc scan, ScanDirection dir)
 {
     BiscuitScanOpaque *so = (BiscuitScanOpaque *)scan->opaque;
     
     if (so->current >= so->num_results)
         return false;
     
     scan->xs_heaptid = so->results[so->current];
     so->current++;
     
     return true;
 }
 
 static int64
 biscuit_getbitmap(IndexScanDesc scan, TIDBitmap *tbm)
 {
     BiscuitScanOpaque *so = (BiscuitScanOpaque *)scan->opaque;
     int64 ntids = 0;
     int i;
     
     for (i = 0; i < so->num_results; i++) {
         tbm_add_tuples(tbm, &so->results[i], 1, false);
         ntids++;
     }
     
     return ntids;
 }
 
 static void
 biscuit_endscan(IndexScanDesc scan)
 {
     BiscuitScanOpaque *so = (BiscuitScanOpaque *)scan->opaque;
     
     if (so->results)
         pfree(so->results);
     pfree(so);
 }
 
 /* ==================== OPERATOR SUPPORT ==================== */
 
 PG_FUNCTION_INFO_V1(biscuit_like_support);
 Datum
 biscuit_like_support(PG_FUNCTION_ARGS)
 {
     /* This function tells the planner we can handle LIKE queries */
     PG_RETURN_BOOL(true);
 }
 
 /* ==================== INDEX HANDLER ==================== */
 
 Datum
biscuit_handler(PG_FUNCTION_ARGS)
{
    IndexAmRoutine *amroutine = makeNode(IndexAmRoutine);
    
    amroutine->amstrategies = 2;  /* Changed from 1 to 2 to support more operators */
    amroutine->amsupport = 1;
    amroutine->amoptsprocnum = 0;
    amroutine->amcanorder = false;
    amroutine->amcanorderbyop = false;
    amroutine->amcanbackward = false;
    amroutine->amcanunique = false;
    amroutine->amcanmulticol = false;
    amroutine->amoptionalkey = true;  /* Changed to true - index can return all rows */
    amroutine->amsearcharray = false;
    amroutine->amsearchnulls = false;
    amroutine->amstorage = false;
    amroutine->amclusterable = false;
    amroutine->ampredlocks = false;
    amroutine->amcanparallel = false;
    amroutine->amcaninclude = false;
    amroutine->amusemaintenanceworkmem = false;
    amroutine->amsummarizing = false;
    amroutine->amparallelvacuumoptions = 0;
    amroutine->amkeytype = InvalidOid;
    
    amroutine->ambuild = biscuit_build;
    amroutine->ambuildempty = biscuit_buildempty;
    amroutine->aminsert = biscuit_insert;
    amroutine->ambulkdelete = biscuit_bulkdelete;
    amroutine->amvacuumcleanup = biscuit_vacuumcleanup;
    amroutine->amcanreturn = biscuit_canreturn;
    amroutine->amcostestimate = biscuit_costestimate;
    amroutine->amoptions = biscuit_options;
    amroutine->amproperty = NULL;
    amroutine->ambuildphasename = NULL;
    amroutine->amvalidate = biscuit_validate;
    amroutine->amadjustmembers = biscuit_adjustmembers;
    amroutine->ambeginscan = biscuit_beginscan;
    amroutine->amrescan = biscuit_rescan;
    amroutine->amgettuple = biscuit_gettuple;
    amroutine->amgetbitmap = biscuit_getbitmap;
    amroutine->amendscan = biscuit_endscan;
    amroutine->ammarkpos = NULL;
    amroutine->amrestrpos = NULL;
    amroutine->amestimateparallelscan = NULL;
    amroutine->aminitparallelscan = NULL;
    amroutine->amparallelrescan = NULL;
    
    PG_RETURN_POINTER(amroutine);
}